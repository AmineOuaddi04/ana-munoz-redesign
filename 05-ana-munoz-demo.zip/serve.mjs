import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
const root=resolve('dist');const port=Number(process.env.ANA_DEMO_PORT||4174);
const aliases={'/peinados/':'/cortes-pelo/','/peinados-eventos/':'/novias/','/protesis-capilares/':'/pelucas-protesiscapilares/'};
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.xml':'application/xml; charset=utf-8','.jpg':'image/jpeg','.woff':'font/woff'};
createServer(async(req,res)=>{
  const headers={'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','Cache-Control':'no-cache'};
  try{
    if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,headers);res.end();return;}
    const url=new URL(req.url,`http://127.0.0.1:${port}`);let path=decodeURIComponent(url.pathname);
    if(aliases[path]){res.writeHead(301,{...headers,Location:aliases[path]});res.end();return;}
    let file=resolve(root,'.'+path);if(file!==root&&!file.startsWith(root+sep)){res.writeHead(400,headers);res.end();return;}
    let status=200;
    try{if((await stat(file)).isDirectory()){if(!path.endsWith('/')){res.writeHead(308,{...headers,Location:path+'/'});res.end();return;}file=resolve(file,'index.html');}await stat(file);}catch{file=resolve(root,'404.html');status=404;}
    const data=await readFile(file);res.writeHead(status,{...headers,'Content-Type':types[extname(file)]||'application/octet-stream','Content-Length':data.length});res.end(req.method==='HEAD'?undefined:data);
  }catch{res.writeHead(400,headers);res.end('Solicitud no válida');}
}).listen(port,'127.0.0.1',()=>console.log(`Ana Muñoz · demo local http://127.0.0.1:${port}`));
