$ErrorActionPreference = 'Stop'
$taskDemoUrl = 'http://127.0.0.1:4174/'
function Test-AnaDemo {
    try {
        $taskResponse = Invoke-WebRequest -Uri $taskDemoUrl -UseBasicParsing -TimeoutSec 2
        return ($taskResponse.StatusCode -eq 200 -and $taskResponse.Content.Contains('hero-title'))
    } catch { return $false }
}
if (-not (Test-AnaDemo)) {
    $taskNodeCommand = Get-Command node -ErrorAction SilentlyContinue
    $taskBundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
    if ($taskNodeCommand) { $taskNodePath = $taskNodeCommand.Source }
    elseif (Test-Path -LiteralPath $taskBundledNode) { $taskNodePath = $taskBundledNode }
    else { throw 'Se necesita Node 22 o posterior para abrir esta demo local.' }
    $env:ANA_DEMO_PORT = '4174'
    $taskServePath = Join-Path $PSScriptRoot 'serve.mjs'
    $taskDemoProcess = Start-Process -FilePath $taskNodePath -ArgumentList ('"' + $taskServePath + '"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot '.demo-out.log') -RedirectStandardError (Join-Path $PSScriptRoot '.demo-error.log')
    Set-Content -LiteralPath (Join-Path $PSScriptRoot '.demo.pid') -Value $taskDemoProcess.Id
    for ($taskAttempt = 0; $taskAttempt -lt 12; $taskAttempt++) {
        if (Test-AnaDemo) { break }
        Start-Sleep -Milliseconds 250
    }
    if (-not (Test-AnaDemo)) { throw 'La demo no ha arrancado. Consulta .demo-error.log; el puerto 4174 puede estar ocupado.' }
}
Start-Process $taskDemoUrl
