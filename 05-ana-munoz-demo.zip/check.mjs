import {readFile,readdir,stat} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
const root=resolve('dist');
async function walk(dir){const paths=[];for(const name of await readdir(dir)){const p=resolve(dir,name);if((await stat(p)).isDirectory())paths.push(...await walk(p));else if(p.endsWith('.html'))paths.push(p);}return paths;}
const errors=[];let references=0;
for(const file of await walk(root)){
  const html=await readFile(file,'utf8');
  if((html.match(/<h1\b/g)||[]).length!==1)errors.push(`${file}: debe tener un h1`);
  const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
  if(new Set(ids).size!==ids.length)errors.push(`${file}: IDs duplicados`);
  for(const [,href] of html.matchAll(/(?:href|src)="([^"]+)"/g)){
    if(/^(https?:|tel:|mailto:|data:)/.test(href))continue;
    references++;
    const [path,hash]=href.split('#');let target;
    if(path){target=path.startsWith('/')?resolve(root,'.'+path):resolve(dirname(file),path);try{if((await stat(target)).isDirectory())target=resolve(target,'index.html');await stat(target);}catch{errors.push(`${file}: recurso o ruta ausente ${href}`);continue;}}
    else target=file;
    if(hash){const dest=await readFile(target,'utf8');if(!dest.includes(`id="${hash}"`))errors.push(`${file}: ancla ausente ${href}`);}
  }
  const ld=html.match(/<script type="application\/ld\+json">([^<]+)<\/script>/);
  if(ld){try{JSON.parse(ld[1]);}catch{errors.push(`${file}: JSON-LD inválido`);}}
}
if(errors.length){console.error(errors.join('\n'));process.exitCode=1;}else console.log(`Integridad correcta: ${references} referencias locales, 8 páginas + 404, un h1 por página, IDs únicos y JSON-LD válido.`);
