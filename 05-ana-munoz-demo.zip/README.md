# Ana Muñoz — dos direcciones de diseño

Primera dirección «Una firma en Colón, 9»: apertura tipográfica, azul derivado del patio real y capítulos editoriales. Segunda dirección «El oficio a primera vista»: fotografía de peluquería, servicios y cita visibles de inmediato, tonos cálidos y navegación directa. Ambas están en español y conviven para compararlas.

## Abrir

Con el servidor de esta presentación activo: **http://127.0.0.1:4174/** (primera dirección) y **http://127.0.0.1:4174/v2/** (segunda dirección).

Publicadas como demos en GitHub Pages: https://amineouaddi04.github.io/ana-munoz-redesign/ y https://amineouaddi04.github.io/ana-munoz-redesign/v2/.

En Windows, haz clic derecho sobre `Abrir-demo.ps1` y elige «Ejecutar con PowerShell». El script usa Node instalado o el runtime de Codex si está disponible, comprueba la página y la abre en el navegador. No necesita descargar dependencias.

Alternativa con Node 22 o posterior, desde esta carpeta:

```
node serve.mjs
```

Para modificar y reconstruir:

```
node build.mjs
node check.mjs
```

`dist/` contiene la web estática completa. No abrir `index.html` directamente mediante `file://`: las rutas absolutas necesitan el servidor local. `serve.mjs` escucha únicamente en 127.0.0.1. `ANA_DEMO_PORT` permite escoger otro puerto. El script de apertura guarda un registro local y el PID del proceso que inicia; `Cerrar-demo.ps1` detiene exclusivamente ese proceso.

## Contenido y alcance

Cada dirección tiene 8 páginas: inicio, servicios, corte, color, bodas/eventos, pelucas/soluciones, salón y contacto. La primera incluye navegación con diálogo, índice de servicios interactivo y galería de archivo. La segunda prioriza servicios visibles, navegación directa y contacto fijo en móvil. Todos los recursos de las páginas son locales.

Hay 3 redirecciones locales: `/peinados/` a `/cortes-pelo/`, `/peinados-eventos/` a `/novias/` y `/protesis-capilares/` a `/pelucas-protesiscapilares/`. Rutas desconocidas devuelven HTTP 404 con página propia. La web oficial de negocio y su dominio no se han modificado.

## Datos e imágenes

Dirección, teléfono, WhatsApp y horario contrastados en la web oficial y la ficha pública de Google el **2/10/2026**. La valoración **4,8/68 opiniones** y el extracto de Sofía de la Rica corresponden a esa consulta y están fechados en la interfaz; no se actualizan automáticamente. Fuente: https://www.google.com/maps?cid=15502565011692758120.

Cuatro fotografías auténticas publicadas por el propietario en Google, todas con etiqueta **noviembre de 2020**. Son archivo, no una afirmación sobre el aspecto o el equipo actual. `FUENTES_FOTOGRAFIAS.json` registra URLs, dimensiones, fechas y huellas. El permiso de reutilización en producción sigue sin obtenerse. El emblema AM del favicon procede de la web oficial.

La primera dirección no representa como reales fotografías de clientes o trabajos pendientes. La segunda incluye dos imágenes generadas de concepto: un corte en curso y un retrato de color, ambas etiquetadas en la interfaz como imágenes conceptuales y nunca atribuidas a Ana, clientes o trabajos del salón. Ver `V2-NOTAS.md` para procedencia, referencias y decisiones. Las técnicas, biografía, equipo, tarifas, maquillaje, desplazamientos y proceso de consulta no verificados requieren confirmación con el cliente.

Archivo variable está alojada localmente, con los ejes de peso y ancho conservados y subconjunto de caracteres latinos para reducir carga. Licencia SIL OFL y procedencia en `licenses/`. Fotografías conservadas sin edición; los recortes son de composición CSS.

## Antes de usar como web oficial

Ambas demos publicadas usan `noindex,nofollow` y `robots.txt` bloquea el rastreo. La primera incluye títulos, descripciones, semántica, canonical de cada futura ruta, sitemap y JSON-LD HairSalon con datos públicos. El sitemap es una preparación técnica; no se ha enviado a buscadores. Los enlaces externos no son reservas automáticas. No hay formularios, trackers ni cookies propias.

Para producción: confirmar NAP y horarios, obtener imágenes recientes autorizadas, sustituir todos los textos pendientes, confirmar canal de citas y servicios, revisar avisos legales, completar el mapa de las 19 rutas históricas del inventario entregado, validar canonicals/301 y entonces permitir indexación. Blog, cosmética oncológica, niños, categorías antiguas de pelucas y testimonios históricos requieren decisiones del cliente; no se han convertido en ofertas actuales.
