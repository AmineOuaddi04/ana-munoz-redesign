export const business = {
  name: 'Peluquería Ana Muñoz', phone: '941 230 376', tel: 'tel:+34941230376',
  address: 'Av. de Colón, 9', city: '26003 Logroño · La Rioja',
  maps: 'https://www.google.com/maps?cid=15502565011692758120',
  whatsapp: 'https://wa.me/34654515242',
  instagram: 'https://www.instagram.com/peluqueriaanamunoz/',
  official: 'https://www.xn--peluqueriaanamuoz-txb.com/',
  checked: '2 de octubre de 2026'
};
export const services = [
  {id:'corte', number:'01', name:'Corte & estilo', short:'CORTE', route:'/cortes-pelo/',
    title:'Un corte empieza\npor una conversación.',
    description:'Cuéntanos qué quieres cambiar, qué quieres conservar y cómo llevas el pelo en tu día a día.',
    detail:'Corte y peinado en Logroño. Para consultar las opciones y encontrar una cita, habla directamente con el salón.',
    pending:'[CONFIRM WITH CLIENT: tipos de corte, asesoramiento incluido y tarifas actuales]',
    question:'¿Qué te gustaría cambiar?', picture:'01 / CORTE', tone:'chalk'},
  {id:'color', number:'02', name:'Color', short:'COLOR', route:'/color-tintes/',
    title:'Hablemos\nde tu color.',
    description:'Un cambio de tono, mantener el color o resolver una duda. Empieza contándonos cómo está tu cabello ahora.',
    detail:'La coloración forma parte de la oferta pública del salón. Las técnicas, productos, duración y precio deben concretarse con Ana.',
    pending:'[CONFIRM WITH CLIENT: técnicas de color, mechas, biotintes y productos vigentes]',
    question:'¿Mantener o cambiar?', picture:'02 / COLOR', tone:'blue'},
  {id:'eventos', number:'03', name:'Bodas & eventos', short:'EVENTOS', route:'/novias/',
    title:'Una fecha.\nMuchas ganas.',
    description:'Novias, invitadas y ocasiones para las que quieres pensar el peinado con tiempo. Cuéntanos la fecha y lo que tienes en mente.',
    detail:'El salón anuncia bodas y eventos. Consulta disponibilidad y opciones de peinado para tu fecha antes de cerrar los detalles.',
    pending:'[CONFIRM WITH CLIENT: pruebas, maquillaje, desplazamientos, horarios y condiciones]',
    question:'¿Para qué fecha?', picture:'03 / EVENTOS', tone:'blue'},
  {id:'pelucas', number:'04', name:'Pelucas & soluciones', short:'PELUCAS', route:'/pelucas-protesiscapilares/',
    title:'Tus preguntas.\nA tu ritmo.',
    description:'Consulta las opciones de pelucas y prótesis capilares directamente con el salón. No necesitas contar información personal aquí.',
    detail:'Pelucas y prótesis capilares aparecen en la ficha pública del negocio y en opiniones recientes. Para disponibilidad y opciones, consulta con el salón.',
    pending:'[CONFIRM WITH CLIENT: consulta privada, adaptación, mantenimiento y catálogo actual]',
    question:'¿Cómo podemos orientarte?', picture:'04 / CONSULTA', tone:'quiet'}
];
export const hours = [
  ['Lunes — miércoles','09:30 — 17:00'], ['Jueves','09:30 — 13:30 / 16:30 — 20:00'],
  ['Viernes','09:00 — 19:00'], ['Sábado','09:00 — 14:00'], ['Domingo','Cerrado']
];
export const photos = {
  interior: {src:'/assets/salon-interior-2020.jpg', alt:'Interior del salón Ana Muñoz: puestos, espejos y zona de espera. Fotografía de archivo de noviembre de 2020.',w:1536,h:2048},
  facade: {src:'/assets/salon-fachada-2020.jpg',alt:'Fachada de Peluquería Ana Muñoz con el emblema AM. Archivo de noviembre de 2020.',w:1362,h:1192},
  patio: {src:'/assets/salon-patio-2020.jpg',alt:'Patio del salón con paredes azules y plantas. Archivo de noviembre de 2020.',w:2048,h:1536},
  people: {src:'/assets/salon-tres-mujeres-2020.jpg',alt:'Retrato de tres mujeres publicado por el salón en noviembre de 2020. Sus identidades y vinculación actual están pendientes de confirmar.',w:1536,h:2048}
};
