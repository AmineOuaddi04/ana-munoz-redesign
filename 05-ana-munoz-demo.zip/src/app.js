const services = JSON.parse(document.querySelector('#service-data').textContent);
class ServiceIndex extends HTMLElement {
  connectedCallback(){
    this.buttons=[...this.querySelectorAll('[data-service]')];
    this.buttons.forEach(button=>{
      button.addEventListener('click',()=>this.select(button.dataset.service));
      button.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse'&&matchMedia('(hover: hover)').matches)this.select(button.dataset.service);});
      button.addEventListener('keydown',event=>{if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();let i=this.buttons.indexOf(button);i=event.key==='Home'?0:event.key==='End'?this.buttons.length-1:(i+(event.key==='ArrowDown'?1:-1)+this.buttons.length)%this.buttons.length;this.buttons[i].focus();this.select(this.buttons[i].dataset.service);}});
    });
  }
  select(id){
    const s=services.find(x=>x.id===id);if(!s)return;
    this.buttons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.service===id)));
    const picture=this.querySelector('[data-service-picture]');
    picture.querySelector('.pending-corner').textContent=`${s.number} / TRABAJO REAL`;
    picture.querySelector('.pending-display').textContent=s.short;
    picture.querySelector('.photo-pending').className=`photo-pending tone-${s.tone}`;
    this.querySelector('[data-service-question]').textContent=s.question;
    this.querySelector('[data-service-description]').textContent=s.description;
    const link=this.querySelector('[data-service-link]');link.href=s.route;link.textContent=`Sobre ${s.name.toLocaleLowerCase('es')}`;
    const panel=this.querySelector('.service-panel');panel.classList.remove('is-switching');requestAnimationFrame(()=>panel.classList.add('is-switching'));
  }
}
customElements.define('service-index',ServiceIndex);
const header=document.querySelector('.site-header');let scrollQueued=false;
window.addEventListener('scroll',()=>{if(!scrollQueued){requestAnimationFrame(()=>{header.classList.toggle('is-scrolled',scrollY>100);scrollQueued=false;});scrollQueued=true;}},{passive:true});
const returnTargets=new WeakMap();
function openDialog(dialog,trigger){if(!dialog||dialog.open)return;returnTargets.set(dialog,trigger);dialog.showModal();document.documentElement.classList.add('dialog-is-open');}
document.querySelectorAll('[data-open]').forEach(button=>button.addEventListener('click',()=>openDialog(document.getElementById(button.dataset.open),button)));
document.querySelectorAll('[data-contact]').forEach(link=>link.addEventListener('click',event=>{
  if(event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
  event.preventDefault();const dialog=document.querySelector('#contact-dialog');
  dialog.querySelector('[data-contact-topic]').textContent=link.dataset.topic?`Consulta sobre ${link.dataset.topic.toLocaleLowerCase('es')}. Habla con el salón para concretar opciones y disponibilidad.`:'Habla directamente con el salón para consultar disponibilidad.';
  openDialog(dialog,link);
}));
document.querySelectorAll('dialog').forEach(dialog=>{
  dialog.querySelectorAll('[data-close]').forEach(button=>button.addEventListener('click',()=>dialog.close()));
  dialog.addEventListener('close',()=>{document.documentElement.classList.remove('dialog-is-open');returnTargets.get(dialog)?.focus({preventScroll:true});});
  dialog.addEventListener('keydown',event=>{
    if(event.key!=='Tab')return;
    const items=[...dialog.querySelectorAll('a[href],button:not([disabled]),[tabindex="0"]')].filter(el=>el.getClientRects().length);
    const first=items[0],last=items.at(-1);
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
  });
  dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
  dialog.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>dialog.close()));
});
const gallery=document.querySelector('#gallery-dialog');
const archivePhotos=[
  {id:'interior',src:'/assets/salon-interior-2020.jpg',alt:'Interior del salón en noviembre de 2020.',caption:'El interior · archivo del salón, noviembre de 2020.'},
  {id:'patio',src:'/assets/salon-patio-2020.jpg',alt:'Patio azul del salón en noviembre de 2020.',caption:'El patio · archivo del salón, noviembre de 2020.'},
  {id:'facade',src:'/assets/salon-fachada-2020.jpg',alt:'Fachada AM del salón en noviembre de 2020.',caption:'Colón, 9 · archivo del salón, noviembre de 2020.'},
  {id:'people',src:'/assets/salon-tres-mujeres-2020.jpg',alt:'Retrato de tres mujeres publicado por el salón en noviembre de 2020.',caption:'Retrato de archivo · noviembre de 2020. Identidades y vinculación actual por confirmar.'}
];
const workPhotos=[
  {id:'01',name:'CORTE',caption:'01 / Forma y detalle. Fotografía real pendiente de facilitar y autorizar por el salón.'},
  {id:'02',name:'COLOR',caption:'02 / Tono y textura. Fotografía real pendiente de facilitar y autorizar por el salón.'},
  {id:'03',name:'PEINADO',caption:'03 / Movimiento y ocasión. Fotografía real pendiente de facilitar y autorizar por el salón.'}
];
let galleryMode='archive',galleryIndex=0;
function renderGallery(){
  const entries=galleryMode==='archive'?archivePhotos:workPhotos;galleryIndex=(galleryIndex+entries.length)%entries.length;
  const item=entries[galleryIndex],view=gallery.querySelector('[data-gallery-view]');view.replaceChildren();
  gallery.querySelector('#gallery-title').textContent=galleryMode==='archive'?'Archivo del salón · 2020':'Trabajo real · selección pendiente';
  if(galleryMode==='archive'){const img=document.createElement('img');img.src=item.src;img.alt=item.alt;view.append(img);}
  else{const placeholder=document.createElement('div');placeholder.className='photo-pending';const word=document.createElement('span');word.className='pending-display';word.textContent=item.name;placeholder.append(word);view.append(placeholder);}
  const caption=document.createElement('p');caption.textContent=item.caption;view.append(caption);
  gallery.querySelector('[data-gallery-counter]').textContent=`${galleryIndex+1} / ${entries.length}`;
}
document.querySelectorAll('[data-photo],[data-work]').forEach(button=>button.addEventListener('click',()=>{
  galleryMode=button.dataset.photo?'archive':'work';const entries=galleryMode==='archive'?archivePhotos:workPhotos;
  galleryIndex=entries.findIndex(x=>x.id===(button.dataset.photo||button.dataset.work));renderGallery();openDialog(gallery,button);
}));
gallery.querySelector('[data-gallery-prev]').addEventListener('click',()=>{galleryIndex--;renderGallery();});
gallery.querySelector('[data-gallery-next]').addEventListener('click',()=>{galleryIndex++;renderGallery();});
gallery.addEventListener('keydown',event=>{if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();galleryIndex+=event.key==='ArrowRight'?1:-1;renderGallery();}});
if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-revealed');observer.unobserve(entry.target);}}),{threshold:.12});
  document.querySelectorAll('.photo-reveal').forEach(el=>{el.classList.add('has-mask');observer.observe(el);});
}
