$taskPidFile = Join-Path $PSScriptRoot '.demo.pid'
if (Test-Path -LiteralPath $taskPidFile) {
    $taskDemoPid = [int](Get-Content -LiteralPath $taskPidFile)
    $taskDemoProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $taskDemoPid" -ErrorAction SilentlyContinue
    $taskServePath = Join-Path $PSScriptRoot 'serve.mjs'
    if ($taskDemoProcess -and $taskDemoProcess.Name -eq 'node.exe' -and $taskDemoProcess.CommandLine.IndexOf($taskServePath, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
        Stop-Process -Id $taskDemoPid -ErrorAction SilentlyContinue
    }
}
