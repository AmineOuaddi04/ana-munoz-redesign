# Dirección 02 — El oficio a primera vista

Segunda propuesta para Peluquería Ana Muñoz, disponible en `/v2/`. Convive con la primera dirección para compararlas. Una fotografía conceptual de corte en acción abre la página; el nombre, la ubicación, los servicios y la cita aparecen inmediatamente, incluso en móvil. La fotografía real del salón conserva su fecha de archivo y las imágenes generadas se identifican como conceptuales.

## Decisiones

- Cabecera con Corte, Color, Bodas, Pelucas y El salón directamente accesibles en escritorio; menú móvil sencillo y dos acciones fijas para llamar o pedir cita.
- Accesos a los cuatro servicios justo debajo de la portada, seguidos de tarjetas completas con enlaces directos; ninguna categoría depende de una interacción para descubrirse.
- Color marfil, tinta, cobre y salvia, con contraste entre grotesca de alto impacto y serif editorial. La escala se reserva para titulares; la información de cita y horarios se lee en tamaños prácticos.
- La cita lleva a teléfono y WhatsApp publicados por el salón, sin simular una reserva ni recoger datos.

## Referencias revisadas y traducción

| Referencia | Lección útil | Traducción para Ana Muñoz |
| --- | --- | --- |
| [Jo Hansford](https://johansford.com/) | Servicios con nombre, imagen y salida clara. | Corte, Color, Bodas y Pelucas visibles en la primera navegación. |
| [Haug London Haus](https://www.hauglondon.com/) | Contenido de peluquería concreto y jerarquía de consulta. | Mensajes sobre el pelo y una ruta directa a contacto. |
| [360 Salon](https://www.threesixtysalon.com/) | Fotografía de cabello como identificador inmediato. | Primera imagen muestra manos, peine, tijeras y cabello. |
| [Aesop Hair](https://www.aesop.com/hair/?geo=false) | Tipografía disciplinada y categorías legibles. | Espaciado amplio con etiquetas cortas y descriptivas. |
| [Glossier](https://www.glossier.com/) | Belleza humana y lenguaje cercano. | Titular en segunda persona y retrato de textura natural. |
| [Acne Studios](https://www.acnestudios.com/uk/en/woman/ss26/) | Escala fotográfica editorial. | Imagen dominante sin ocultar la cita y los servicios. |
| [Byredo Hair Perfume](https://www.byredo.com/us_en/c/perfume/personal-fragrances/categories/hair-perfumes) | Restricción cromática. | Base cálida y un acento cobre que remite al color del cabello. |
| [Into The Gloss](https://intothegloss.com/pages/about) | Voz editorial cotidiana. | Información útil, breve y sin promesas de lujo inventadas. |

Son referencias de principios visuales, no plantillas. No se copian contenidos, fotografías ni estructuras de esas marcas.

## Imágenes nuevas

`assets/v2-corte.jpg` y `assets/v2-color.jpg` se generaron con la herramienta integrada `image_gen`, en modo `photorealistic-natural`, como imágenes de concepto para esta segunda dirección. Ninguna muestra al equipo, a clientes o trabajos reales de Peluquería Ana Muñoz. Los originales PNG de generación están en el almacén de imágenes de Codex; los JPEG optimizados están en este proyecto. Prompt resumido: corte realista en curso con manos, tijeras y peine en un salón independiente de ambiente cálido; retrato editorial de cabello cobrizo con textura natural. Se pidió ausencia de logos, textos y personas reconocibles.

Las fotos reales de interior, fachada y patio provienen del archivo público de noviembre de 2020 indicado en `FUENTES_FOTOGRAFIAS.json`. Su permiso de publicación y vigencia se debe confirmar con Ana antes de utilizar cualquiera de las dos direcciones como web oficial.
